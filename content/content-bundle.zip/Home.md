# Bem Vindos!
Sejam Bem vindos ao meu caderno de estudos particular, nele ire demonstrar um pouco da minha jornada no mundo da programação e curiosidadades vinculdadas ao assunto.

# Atenção!

**==Conteudo em criação.==**

## Quem sou eu?

Prazer meu nome é  Arthur Souza, sou um estudante de T.I que deseja ingressar na área e ajudar a desenvolver/manter soluções elegantes para problemas desde simples a complexos.

## Qual meu objetivo?

Meu objetivo neste momento, e a revisão completa dos meus conhecimentos atraves desses sistema de MarkBase/Obsidian a fim de gerar um conunto de informações capazes de ajudar, tanto a mim, quanto a qualquer um que deseje revisar os conhecimentos da área.


# [[RoadMap]]
