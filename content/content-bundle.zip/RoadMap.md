# OBJETIVO
Vou reiniciar do zero, reaprender Programação novamente, revisando modelos e estruturas a fundo, revisitando o jardim da logica e aprendendo de verdade.
E a longo prazo esse deve se tornar um grande centro de conhecimento da área, que pose ser revisitado para estudos e consultas, meu grande objetivo a longo prazo é o domínio da Programação e a prática do Hacker ético.

## O início - O fundamento.

Para o início tenho que rever a base de tudo que virá, **A lógica**, ela é a base de toda a computação, a [[2022-08-30 - lógica de programação]]  e os [[algoritimos]] nos ensina como pensar conforme o computador processa os dados, para que chegarmos a uma linguagem comum, um meio termo *Humano Maquina*.

Outro fundamento escolhido para compor meu estudo é a [[prototipagem]] , esse é um pilar composto por vários pontos interessantes como sua ligação com os modelos da [[UML]], e até mesmo com a parte de [[UX]].

E por fim o fundamento do [[Modelo de Negocio]], apesar de **não técnico**, esse pilar serve de *base para tudo*, pois a área de TI só existe para ==resolver problemas e melhorar [[Processos sistêmicos]]==, e isso tudo deriva do [[Modelo de Negocio]] a qual o projeto é aplicado, então para isso entender como um [[Modelo de Negocio]] se dá, como analiar e como melhorar e um grande ponto.

# A escolha....
Neste ponto eu devo escolher um guia de conhecimento ou re-aprendizagem, pois apesar do fundamento ser comum, cada área demanda uma especialização diferente, a lista a abaixo contem links para os guias de entendimento de cada área, meu ==Principal Objetivo== é conseguir aprender o maximo, me tornando:
( Vou colocar trilhar mais especificas em [[Roadmap - estudos TI]])
## No quesito tecnico ([[HardSkill]]):
### Especialista em [[Java]] e [[Flutter]] 
#### Com o conhecimento avançado de [[JS]]/[[TypeScripty]], [[Golang]], [[Python]], [[Meta-Verso]],[[Web3]] e [[UX]] 
##### Tendo conhecimento intermediario em [[Rust]], [[Vunerabilidades]],[[Linux]],[[windows]],[[Data Science]], [[IA]],[[BD]] e [[redes]]
###### Com uma base ==legal== de [[C]], [[C++]], [[prototipagem]], [[git]], [[html]],[[css]] , [[Dapps]] e [[tecnologia descentralizada]].

## No quesito Humano ([[SoftSkill]]):
### O cara em [[Liderança]]
### A referencia em [[TeamWotk]]
#### Um ser pura [[Criatividade]] e [[empatia]]
### Não um Grande mas um bom [[Comunicador]]
### Referencia em [[agile]]
### E acima de tudo um [[Facilitador]] de [[crecimento profissional]] alheio.
---
## Mas para que isto tudo?
Em termos praticos, quero ser um ==Profissional Versatil ==, com um ***amplo conhecimento Teorico e Pratico*** com a capacidade de lidar com diversos problemas e com liberdade e poder de estar presente e ajudar equipes em todos os momentos. Alem disso um profissional deste calibre e ==Muito Bem Pago ==.
___
## Em termos praticos, Qual o Foco?
Para o foco principal temos a plataforma mais ampla [[Java]] com o objetivo de:
	- aumentar o alcance no mercado de trabalho;
	- grande base de softwares legados para manutenção.
	- Versatil.
E como segundo ponto o [[Flutter]]: 
	- MOTOR [[FLUSHIA]];
	-  Linguagem com foco em [[UX]] 
	- MultiPlataforma;
	- Apoiada/Criada pelo Google;
	- Possivel novo [[SO]] baseada nela; 